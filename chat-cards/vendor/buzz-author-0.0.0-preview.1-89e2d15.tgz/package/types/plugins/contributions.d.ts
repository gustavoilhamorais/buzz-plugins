import type { Context } from "@deepseek-ai/cordis";
export type Contribution<T> = Readonly<T & {
    key: string;
    pluginId: string;
    revision: string;
}>;
/** How strongly a contribution claims a target: lower wins, default 0. Bands by
 * convention: -10 specialises a known plugin, 0 default/specific, 100 catch-all. */
export type MatchOrder = number | ((target: string) => number);
/** Among active matches, the lowest order for this target wins; ties fall to the
 * contribution key so activation or re-enable order never decides. A throwing
 * matcher is skipped; a throwing or non-finite order counts as the default. */
export declare function resolveMatch<T extends {
    matches(target: string): boolean;
    order?: MatchOrder | undefined;
}>(entries: readonly Contribution<T>[], target: string): Readonly<T & {
    key: string;
    pluginId: string;
    revision: string;
}> | undefined;
export declare function createContributions<T extends {
    id: string;
}>(root: Context): {
    snapshot: () => readonly Readonly<T & {
        key: string;
        pluginId: string;
        revision: string;
    }>[];
    subscribe(listener: () => void): () => void;
    /** Returns a function that removes it before its scope ends. */
    register(ctx: Context, value: T): () => void;
};
