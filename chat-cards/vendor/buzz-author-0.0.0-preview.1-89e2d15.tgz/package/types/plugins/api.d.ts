import type { Context, Inject } from "@deepseek-ai/cordis";
import type * as React from "react";
export type PluginManifest = Readonly<{
    id: string;
    name: string;
    apiVersion: 1;
    description?: string;
    /** Author-supplied browsing metadata. It never grants host capabilities. */
    discovery?: Readonly<{
        /** Stable category slug. Hosts may group unrecognized values under Other. */
        category?: string;
        /** Readable tags: 1–80 UTF-8 bytes each, no control characters, at most 16.
         * Duplicate comparison collapses whitespace and uses Unicode lowercase. */
        tags?: readonly string[];
    }>;
    host?: Readonly<{
        /** Observe and influence native hook events for these agent type keys. */
        agentHooks?: readonly string[];
        commands?: readonly Readonly<{
            id: string;
            program: string;
            args: readonly string[];
            /** Opt-in UTF-8 stdin bound, at most 65536 bytes; absent means no input. */
            maxInputBytes?: number;
            /** Maximum UTF-8 stdout bytes; defaults to 4096, bounded at 1048576. */
            maxOutputBytes?: number;
        }>[];
        networkOrigins?: readonly string[];
        /** Programs the plugin may start with `host.spawn`; the caller's
         * arguments follow the declared ones. */
        processes?: readonly Readonly<{
            id: string;
            program: string;
            args?: readonly string[];
            /** Run the copy the app ships, never one on PATH. */
            bundled?: boolean;
        }>[];
        /** The plugin may serve MCP with `host.serveMcp`, including tools for
         * commands bound to an Attention source run. */
        mcp?: boolean;
        /** The plugin may read files with `host.readFile` and resolve directories
         * with `host.resolveDirectory`, with the user's own access. */
        files?: boolean;
    }>;
}>;
export type PluginModule = {
    inject?: Inject;
    apply: (ctx: Context) => void | Promise<void>;
};
declare module "@deepseek-ai/cordis" {
    interface Context {
        react: typeof React;
        readonly pluginOwner?: Readonly<{
            id: string;
            revision: string;
            agentHooks?: readonly string[];
        }>;
    }
}
