import { Service, type Context } from "@deepseek-ai/cordis";
export type HostRequest = Readonly<{
    url: string;
    method?: "GET" | "HEAD" | "POST" | "PUT" | "PATCH" | "DELETE";
    headers?: Readonly<Record<string, string>>;
    body?: string;
    /** Native deadline in milliseconds, 1–180000. Defaults to 30000. */
    timeoutMs?: number;
}>;
/** A multipart POST of one local `.tar.gz` file in the home directory, with
 * text fields beside it, to an origin the plugin declares. */
export type HostUpload = Readonly<{
    url: string;
    headers?: Readonly<Record<string, string>>;
    fields?: Readonly<Record<string, string>>;
    file: Readonly<{
        /** The form field it is sent as. */
        field: string;
        /** An absolute path. */
        path: string;
        /** The file name the form gives it. */
        name: string;
        contentType: string;
    }>;
}>;
export type HostResponse = Readonly<{
    status: number;
    headers: Readonly<Record<string, string>>;
    body: string;
}>;
/** Reusable NIP-OA proof for one agent key; preparing it does not submit it. */
export type NipOaAuthorization = readonly [
    "auth",
    ownerPubkey: string,
    conditions: string,
    signature: string
];
export type HostProcessOptions = Readonly<{
    /** Follow the arguments the manifest declares. */
    args?: readonly string[];
    /** An absolute directory or one under home written `~/…`; created if missing. */
    cwd?: string;
    /** Added to the app's environment; `null` removes a variable. */
    env?: Readonly<Record<string, string | null>>;
    /** Run with one app-held MCP session and an agent-scoped `buzz` on PATH. */
    mcp?: Pick<HostMcpServer, "url" | "headers">;
    onStdout?(data: string): void;
    onStderr?(data: string): void;
}>;
export type HostProcess = Readonly<{
    write(data: string): Promise<void>;
    /** Writes any final `data`, then closes stdin. */
    end(data?: string): Promise<void>;
    /** Asks it to stop, then kills it and its descendants. */
    kill(): Promise<void>;
    /** The exit code once it exits; null when a signal ended it. */
    exited: Promise<number | null>;
}>;
/** Answers one JSON-RPC message an agent sent: with the JSON-RPC response,
 * or `undefined` for a notification, which needs none. */
export type McpHandler = (message: unknown) => Promise<unknown>;
/** A loopback MCP server (Streamable HTTP) whose messages the plugin answers.
 * It belongs to the plugin and stops when the plugin unloads. */
export type HostMcpServer = Readonly<{
    /** `http://127.0.0.1:<port>/mcp` */
    url: string;
    /** What the agent must send with each request, as ACP's `mcpServers` and
     * MCP clients take them. */
    headers: readonly Readonly<{
        name: string;
        value: string;
    }>[];
    close(): Promise<void>;
    /** Resolves once it has stopped. */
    closed: Promise<void>;
}>;
/** Share one MCP session among cooperating clients holding the token.
 * This permits token reuse after initialization. The handler must bind identity
 * itself and grant every client the same authority. Defaults to false. */
export type HostMcpOptions = Readonly<{
    sharedSession?: boolean;
}>;
export interface Host {
    runCommand(id: string, input?: string): Promise<string | null>;
    /** Starts a process the manifest declares in `host.processes`. It lives until
     * it exits, is killed, or the plugin unloads. Desktop only. */
    spawn?: (id: string, options?: HostProcessOptions) => Promise<HostProcess>;
    /** Starts a loopback MCP server whose messages `handler` answers, for a
     * plugin whose manifest declares `host.mcp`. Desktop only. */
    serveMcp?: (handler: McpHandler, options?: HostMcpOptions) => Promise<HostMcpServer>;
    /** Reads a file of at most 50 MB, for a plugin whose manifest declares
     * `host.files`. `path` is absolute, `~/…`, or relative to `cwd`, which is
     * absolute or `~/…`. A missing file rejects with "No such file". Desktop
     * only. */
    readFile?: (path: string, options?: Readonly<{
        cwd?: string;
    }>) => Promise<Uint8Array>;
    /** `path`, absolute or `~/…`, as an absolute directory without symbolic
     * links, created if missing, for a plugin whose manifest declares
     * `host.files`. Desktop only. */
    resolveDirectory?: (path: string) => Promise<string>;
    request(input: HostRequest): Promise<HostResponse>;
    /** Uploads a file as `request` sends a body. Desktop only. */
    upload?: (input: HostUpload) => Promise<HostResponse>;
    prepareRemoteAgentAuthorization?: (agentPubkey: string, signal?: AbortSignal) => Promise<NipOaAuthorization>;
}
declare module "@deepseek-ai/cordis" {
    interface Context {
        host: Host;
    }
}
/** The signed-in owner's NIP-OA proof for `agentPubkey`, from native
 * identity or the web relay proxy. */
export declare function prepareRemoteAgentAuthorization(agentPubkey: string, signal?: AbortSignal): Promise<NipOaAuthorization>;
export declare class HostService extends Service implements Host {
    constructor(context: Context);
    prepareRemoteAgentAuthorization(agentPubkey: string, signal?: AbortSignal): Promise<NipOaAuthorization>;
    runCommand(id: string, input?: string): Promise<string | null>;
    spawn(id: string, { onStdout, onStderr, ...options }?: HostProcessOptions): Promise<HostProcess>;
    serveMcp(handler: McpHandler, options?: HostMcpOptions): Promise<HostMcpServer>;
    readFile(path: string, { cwd }?: Readonly<{
        cwd?: string;
    }>): Promise<Uint8Array>;
    resolveDirectory(path: string): Promise<string>;
    request(input: HostRequest): Promise<HostResponse>;
    upload(input: HostUpload): Promise<HostResponse>;
}
/** The reply to one HTTP body, which carries one message: MCP has no batches
 * since its 2025-06-18 revision. A handler that throws answers a request with
 * an internal error. */
export declare function answerMcp(handler: McpHandler, body: string): Promise<unknown>;
