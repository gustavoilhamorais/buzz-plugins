import type { UserStatuses } from "../relay/user-status";
export declare function useUserStatus(statuses: UserStatuses | undefined, userId: string): Readonly<{
    userId: string;
    text: string;
    emoji: string;
    emojiUrl?: string;
    updatedAt: number;
    expiresAt?: number;
}> | undefined;
