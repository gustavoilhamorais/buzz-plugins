import type { MentionRecipient } from "../messages/mention-draft";
import type { RelaySession } from "../relay/session";
/** Makes an agent the one new Berd messages are tagged for, on this device. */
export declare function setDefaultAgent(scope: string, pubkey: string): boolean;
/** Abandon a failed account replacement without overwriting a newer device
 * choice made while its confirmation remained open. */
export declare function restoreDefaultAgent(scope: string, replacing: string, previous: string): boolean;
/** The viewer's own choice: saved here, then to their account. */
export declare function chooseDefaultAgent(session: RelaySession, scope: string, pubkey: string): Promise<void>;
/** A deleted agent stops being the main agent everywhere it was chosen; the
 * next available one takes over and is saved on this device. One left on the
 * account is stood in for like any deleted choice, until the next choice. */
export declare function forgetDefaultAgent(pubkey: string): void;
/** The agent saved as main on the viewer's account, when it has one; without
 * an account record, the agent saved on this device. */
export declare function useSavedAgent(session: RelaySession, scope: string): string | undefined;
/** The agent explicitly saved as main, whether or not it can be tagged now. */
export declare function useChosenAgent(scope: string): string | undefined;
/**
 * The agent new Berd messages are tagged for. A chosen main agent stays chosen
 * for as long as it exists, even when its runtime is signed out or broken, so
 * a failure shows on the agent the viewer expects. Without a choice, or once
 * the chosen agent is deleted (archived), and once the account's saved choice
 * has been read, the first agent the viewer runs here, else the first they
 * can tag, becomes the main agent and is saved on this device so it doesn't
 * shift between loads. A chosen agent missing for another reason
 * is stood in for without replacing the choice. Bestie may own this choice
 * later. A requested agent, as when search opens a new chat with it, replaces
 * that choice: it is tagged once it can be, and no other agent stands in for
 * it.
 */
export declare function useDefaultAgent(session: RelaySession, scope: string, requested?: string): MentionRecipient | undefined;
