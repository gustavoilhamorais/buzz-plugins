import { type ReadFilter, type RelayEvent } from "./events";
export type WindowCursor = Readonly<{
    createdAt: number;
    eventId: string;
}>;
export type WindowPage = Readonly<{
    events: RelayEvent[];
    cursor: WindowCursor | null;
    hasMore: boolean;
}>;
export declare const WINDOW_PAGE_SIZE = 20;
/** Row kinds a window page reads. Membership notices (40099) are read apart by
 * `noticeFilter`: a page counts every row kind against its limit, so a burst
 * of joins would otherwise fill pages and hold the messages back. */
export declare const WINDOW_KINDS: readonly number[];
export declare const NOTICE_PAGE_SIZE = 500;
/** NIP-CW window request: top-level rows plus aux closure and thread summaries, paged by the relay's composite cursor. */
export declare function windowFilter(channelId: string, cursor: WindowCursor | null, limit?: number): ReadFilter;
/** The relay's membership notices in a channel, newest first, below `cursor`
 * by the same composite keyset the window pages use. */
export declare function noticeFilter(channelId: string, relayAuthor: string, cursor: WindowCursor | null): ReadFilter;
/** The relay answers each served window with exactly one signed kind 39006 bounds event. Anything else is rejected;
 * an absent or malformed bound must never be mistaken for "no more history". */
export declare function parseWindow(channelId: string, cursor: WindowCursor | null, relayAuthor: string, events: readonly RelayEvent[]): WindowPage;
