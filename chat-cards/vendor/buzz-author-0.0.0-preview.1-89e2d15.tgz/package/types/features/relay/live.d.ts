import { type ObserverFrame } from "../agents/observer.ts";
import type { EventTemplate, VerifiedEvent } from "nostr-tools";
import type { ArtifactSyncFilter, ArtifactSyncSink } from "./artifact-sync-filter.ts";
export declare const LIVE_CHANNEL_CAPACITY = 1022;
export declare const LIVE_BATCH_SIZE = 10;
export declare const LIVE_REPLAY_LIMIT = 500;
export declare const LIVE_RECOVERY_INTERVAL = 60000;
/** Channel REQs awaiting EOSE at once. `scripts/live-setup-probe.mjs` compares others. */
export declare const SETUP_CONCURRENCY = 4;
/** How long one channel REQ may wait for EOSE before its route fails. */
export declare const SETUP_TIMEOUT_MS = 10000;
/** The relay rejects an event whose created_at is further than this from its own
 * clock (block/buzz `crates/buzz-relay/src/handlers/ingest.rs`,
 * `MAX_TIMESTAMP_DRIFT_SECS`), so an event stored at time T can carry any
 * created_at in [T - 900, T + 900]. */
export declare const RELAY_TIMESTAMP_DRIFT_SECS = 900;
/** A route that reached EOSE was delivered live until its connection last heard
 * the relay. An event stored just after that can be backdated by the full drift,
 * so resume this far before it, plus one minute shared by everything else the
 * clocks disagree on: fan-out still in flight when the relay closed (a draining
 * pod can trail its peers), the client clock's skew from the relay's, and the
 * relay's replica read budget for the unread repair, which uses the same margin. */
export declare const LIVE_RESUME_LAG: number;
/** The first reconnect after such a close waits a uniform random time up to
 * this, so a fleet the relay closed at once does not return at once. */
export declare const LIVE_RESTART_SPREAD_MS = 10000;
/** What a route knew when its authenticated connection ended (unix seconds). */
export type LiveCursor = Readonly<{
    liveUntil: number;
}>;
/** Where a route with a cursor resumes: `LIVE_RESUME_LAG` before its connection
 * last heard the relay, never before `original`, the first window of the session.
 * The cursor exists only for a route that reached EOSE, so everything after the
 * EOSE was delivered live until `liveUntil`; the lag keeps the overlap. */
export declare function liveResumeSince(original: number, cursor: LiveCursor): number;
/** Delay before the next connection attempt. A restarting relay (1001/1012)
 * gets full jitter over the spread window, widening once repeated bounces have
 * grown the backoff past it. Anything else waits half to all of the backoff.
 * `random` is in [0, 1). */
export declare function liveReconnectDelay(closeCode: number | undefined, backoff: number, random: () => number): number;
export declare const liveSlowRetryDelay: (failures: number) => number;
/** Host-owned server cooldown survives socket/POST replacement.
 * Healthy traffic has no inter-request delay; outstanding work is bounded below. */
export declare function createLiveAdmission(): {
    delay: () => number;
    setup(owner: object, busy: boolean): void;
    presenceReady: () => boolean;
    presenceDelay: () => number;
    tryPresence(): (() => void) | undefined;
    presenceSent(): void;
    presenceIdle: () => boolean;
    pause(seconds: number): void;
};
export type LiveAdmission = ReturnType<typeof createLiveAdmission>;
export type LiveRoute = Readonly<{
    id: string;
    channelId?: string;
    status: "pending" | "live" | "error" | "limited";
    /** EOSE establishes a stream, never proves historical completeness. */
    replay: "unknown" | "limited";
    error?: string;
}>;
export type LiveSnapshot = Readonly<{
    status: "unavailable" | "connecting" | "connected" | "retrying" | "error";
    routes: readonly LiveRoute[];
    error?: string;
}>;
/** Transport provenance, not a history-completeness claim or permission to alert. */
export type LiveProvenance = Readonly<{
    phase: "replay" | "live";
    channelId?: string;
    /** Original wire scope for ambiguous channel traffic; never alert attribution. */
    sourceChannels?: readonly string[];
}>;
export declare function liveProvenance(value: unknown): LiveProvenance;
export type LiveCallbacks = {
    /** Legacy/missing provenance reconciles quietly; it is never implicitly fresh. */
    receive(events: readonly VerifiedEvent[], provenance?: LiveProvenance): void;
    /** Host-only encrypted telemetry route; never ordinary history reconciliation. */
    telemetry?(event: VerifiedEvent, generation: number): void;
    /** Decoded host DTO on the browser transport. */
    observer?(frame: ObserverFrame, generation: number): void;
    presence?(event: VerifiedEvent): void;
    state(snapshot: LiveSnapshot): void;
    established(channels?: string | readonly string[]): void;
    /** Periodic repair hint, not membership or historical-completeness evidence. */
    recover?(): void;
    denied(channelId: string, reason: string): void;
};
export type LiveSubscription = {
    /** Local broker handle; not a relay subscription ID. */
    identity?(): string | undefined;
    publish?(event: VerifiedEvent, signal: AbortSignal): Promise<string>;
    /** Purpose-bound host path when generic socket publication is unavailable. */
    publishTyping?(event: VerifiedEvent, signal: AbortSignal): Promise<string>;
    update(channels: readonly string[], joined?: readonly string[]): void;
    /** Host demand only: reorder existing pending routes, never grant new interests. */
    prioritize?(channels: readonly string[]): void;
    observe?(generation: number | null): void;
    /** Ephemeral status: true = accepted, false = unconfirmed/refused, null = unsent.
     * Admission skips report their remaining delay; no durable queue is created. */
    publishPresence?(status: "online" | "away" | "offline", signal: AbortSignal): Promise<boolean | null | {
        retryAfterMs: number;
    }>;
    watchPresence?(authors: readonly string[]): void;
    /** One NIP-AR sync REQ on this socket. Sent once authenticated; a lost
     * socket ends it with `disconnected:`. The caller owns restart. */
    syncArtifacts?(filter: ArtifactSyncFilter, sink: ArtifactSyncSink): () => void;
    retry(): void;
    dispose(): void;
};
/** Demand-scoped ephemeral authors, never a channel/history interest. */
export declare function livePresenceAuthors(input: unknown): string[];
/** IDs, not names/previews, define interest identity. Never silently truncate. */
export declare function liveChannels(input: unknown): string[];
/** Batchability is part of the same interest snapshot, not a priority hint. */
export declare function liveJoined(channels: readonly string[], input: unknown): string[];
export declare const CHANNEL_KINDS: number[];
/** The browser socket and native header-capable facade share only frame transport. */
export interface LiveSocket {
    readonly readyState: number;
    readonly connectionTimeoutMs?: number;
    onopen: ((event: Event) => unknown) | null;
    onmessage: ((event: MessageEvent) => unknown) | null;
    onerror: ((event: Event) => unknown) | null;
    onclose: ((event: CloseEvent) => unknown) | null;
    send(data: string): void;
    close(): void;
}
/** One authenticated socket, bounded joined-channel batches, singleton previews and two globals.
 * Recent replay is opportunistic: finite reads own catch-up and history bounds. */
export declare function subscribeRelayTraffic(url: string, sign: (event: EventTemplate) => Promise<VerifiedEvent>, viewer: string, callbacks: LiveCallbacks, socketFactory?: (url: string) => LiveSocket, admission?: LiveAdmission, setupConcurrency?: number, setupTimeoutMs?: number, random?: () => number): LiveSubscription;
