import { type BackupFailureKind } from "./backup-failure";
import type { Identity } from "./service";
type Send = <T>(command: string, args?: Record<string, unknown>) => Promise<T>;
/** Resolves to the ticket of the backup pass this handoff starts, or `null` when
 * none will (or the handoff was refused). Never rejects. */
export declare function handoffBackupSession(source: "builderlab" | "hosted", credential: string | null, send?: Send): Promise<number | null>;
/** What the native uploader last did for this device's key. `seq` orders
 * statuses; a pass numbered at or above a handoff's ticket started after it. */
export type BackupStatus = Readonly<{
    seq: number;
    pass: number;
    builderlab: boolean;
} & ({
    status: "idle" | "running" | "complete";
} | {
    status: "waiting";
    reason: "no_consent" | "no_session" | "not_linked";
} | {
    status: "failed";
    kind: "busy" | "signed_out" | "not_offered" | "other_key_linked" | "invalid_service" | "refused" | "unreachable" | "unconfirmed" | "storage";
})>;
/** Nothing is registered until the first `subscribe` or `ready()`. The channel is
 * watched before the snapshot is read and the higher `seq` wins, so a transition
 * between the two is never lost. */
export declare function createBackupStatus(send?: Send): {
    snapshot: () => BackupStatus | undefined;
    ready: () => Promise<Readonly<{
        seq: number;
        pass: number;
        builderlab: boolean;
    } & {
        status: "idle" | "running" | "complete";
    }> | Readonly<{
        seq: number;
        pass: number;
        builderlab: boolean;
    } & {
        status: "waiting";
        reason: "no_consent" | "no_session" | "not_linked";
    }> | Readonly<{
        seq: number;
        pass: number;
        builderlab: boolean;
    } & {
        status: "failed";
        kind: "busy" | "signed_out" | "not_offered" | "other_key_linked" | "invalid_service" | "refused" | "unreachable" | "unconfirmed" | "storage";
    }>>;
    subscribe(listener: () => void): () => void;
    dispose(): void;
};
/** A first-run backup that did not complete, with the table's copy as its message. */
export declare class BackupError extends Error {
    readonly kind: BackupFailureKind;
    readonly retryable: boolean;
    constructor(kind: BackupFailureKind);
}
/**
 * Backs `pubkey` up through the native uploader, the only thing that runs a
 * pass: consent on, then the first-run credential handed to the shared
 * `builderlab` slot, whose ticket names the pass to wait for. The first status
 * at or past it that is not `running` answers, or `timeout` does. The slot is
 * handed back on every exit after the handoff, so the credential never
 * outlives the step; a settled pass is not running, so that publishes nothing
 * and the outcome stays visible. Consent stays on after a failure, so a later
 * Builderlab sign-in may finish what the user asked for; declining turns it off.
 * The caller must hold the `builderlab` slot alone for the step: handing it
 * back empties it rather than restoring an earlier credential, so a signed-in
 * Builderlab plugin would lose its native session until its own changes.
 * Rejects with a `BackupError`.
 */
export declare function backUpWith(identity: Pick<Identity, "backup" | "setBackupChoice">, pubkey: string, credential: string, { timeout, after, send, }?: {
    timeout?: number;
    after?: (ms: number, signal: AbortSignal) => Promise<void>;
    send?: Send;
}): Promise<void>;
export {};
