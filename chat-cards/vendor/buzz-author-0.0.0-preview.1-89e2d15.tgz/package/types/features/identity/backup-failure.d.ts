/**
 * Why "Backing up your key…" did not complete: the copy the failed page shows
 * and whether Try again can help. Native code names its own kinds and retries
 * them all on its next wake; `unavailable`, `interrupted`, `timeout` and
 * `unknown` are the renderer's. No message carries a service or IPC answer.
 * A leaf module: vite.config.ts validates the development seed against it
 * through Node's native loader.
 */
export declare const BACKUP_FAILURES: {
    readonly unavailable: {
        readonly message: "Key backup isn’t available in this version of Buzz.";
        readonly retryable: false;
    };
    readonly busy: {
        readonly message: `${string} ${string}`;
        readonly retryable: true;
    };
    readonly interrupted: {
        readonly message: `${string} ${string}`;
        readonly retryable: true;
    };
    readonly timeout: {
        readonly message: `${string} ${string}`;
        readonly retryable: true;
    };
    readonly signed_out: {
        readonly message: "Your Builderlab sign-in is no longer valid, so your key wasn’t backed up.";
        readonly retryable: false;
    };
    readonly not_offered: {
        readonly message: "Builderlab doesn’t offer key backup for this account yet.";
        readonly retryable: false;
    };
    readonly not_linked: {
        readonly message: "This key isn’t linked to your Builderlab account yet, so it can’t be backed up.";
        readonly retryable: false;
    };
    readonly other_key_linked: {
        readonly message: "Your Builderlab account is linked to a different key, so this one can’t be backed up.";
        readonly retryable: false;
    };
    readonly invalid_service: {
        readonly message: "Buzz couldn’t verify Builderlab’s backup service, so your key wasn’t sent.";
        readonly retryable: false;
    };
    readonly refused: {
        readonly message: "Builderlab refused this backup.";
        readonly retryable: false;
    };
    readonly unreachable: {
        readonly message: `${string} ${string}`;
        readonly retryable: true;
    };
    readonly unconfirmed: {
        readonly message: `${string} ${string}`;
        readonly retryable: true;
    };
    readonly storage: {
        readonly message: `${string} ${string}`;
        readonly retryable: true;
    };
    readonly unknown: {
        readonly message: "Your key wasn’t backed up.";
        readonly retryable: false;
    };
};
export type BackupFailureKind = keyof typeof BACKUP_FAILURES;
export declare const isBackupFailureKind: (value: unknown) => value is BackupFailureKind;
