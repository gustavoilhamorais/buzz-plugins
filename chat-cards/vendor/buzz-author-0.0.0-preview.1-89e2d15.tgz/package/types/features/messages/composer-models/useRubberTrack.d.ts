import { type PointerEvent } from "react";
export declare function useRubberTrack(disabled: boolean): {
    track: import("react").RefObject<HTMLDivElement | null>;
    label: import("react").RefObject<HTMLDivElement | null>;
    handlers: {
        onPointerDown(event: PointerEvent<HTMLDivElement>): void;
        onPointerMove(event: PointerEvent<HTMLDivElement>): void;
        onPointerUp(event: PointerEvent<HTMLDivElement>): void;
        onPointerCancel(event: PointerEvent<HTMLDivElement>): void;
        onLostPointerCapture(event: PointerEvent<HTMLDivElement>): void;
        onKeyDown(): void;
    };
};
