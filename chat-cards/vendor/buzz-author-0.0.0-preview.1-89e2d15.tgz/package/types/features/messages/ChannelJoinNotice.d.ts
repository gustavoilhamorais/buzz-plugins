import type { ChannelLifecycleCapability } from "../relay/channel-lifecycle";
/** Member-default public previews offer Join; the roster alone enables the composer.
 * Confirmed membership can unmount this notice before its run settles, so the
 * page records the join intent when the run starts, not when it resolves. */
export declare function ChannelJoinNotice({ channelId, ready, lifecycle, joinable, guest, joinRole, onJoin, onHeightChange, }: {
    channelId: string;
    ready?: boolean;
    lifecycle?: ChannelLifecycleCapability | undefined;
    joinable: boolean;
    guest?: boolean;
    joinRole?: "member" | "guest" | undefined;
    onJoin(): void;
    onHeightChange?(height: number): void;
}): import("react").JSX.Element;
