import type { Profile } from "../relay/contracts";
import type { RelaySession } from "../relay/session";
/** Verified NIP-OA owner of the profile head the session already retains, for
 * display only, never authorization. The directory verifies each head once and
 * notifies when the verdict lands. Reads no agent profile: the profile pane
 * owns live evidence (`useAgentOwnerEvidence`). Reads the owner's profile from
 * the session directory, since row-selected profiles do not include owners. */
export declare function useProfileOwner(session: RelaySession | undefined, pubkey: string | undefined): {
    id: string;
    profile: Profile | undefined;
} | undefined;
