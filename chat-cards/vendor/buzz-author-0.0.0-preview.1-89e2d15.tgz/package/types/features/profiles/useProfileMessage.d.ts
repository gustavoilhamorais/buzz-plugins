import type { RelaySession } from "../relay/session";
/** Shared profile action: respect community agent readiness and retire stale opens. */
export declare function useProfileMessage({ session, pubkey, viewer, agent, enabled, onOpened, }: {
    session: RelaySession | undefined;
    pubkey: string;
    viewer: string | undefined;
    agent: boolean;
    enabled: boolean;
    onOpened(channelId: string): void;
}): {
    available: boolean;
    opening: boolean;
    error: string;
    open: () => Promise<void>;
};
