/** The full npub of a hex public key, or undefined for anything else. */
export declare function canonicalPublicKey(pubkey: string): string | undefined;
/** Display only: never use this abbreviation for copying, storage or routing. */
export declare function formatPublicKey(pubkey: string, suffixLength?: number): string | undefined;
/** Distinct public identities share the shortest unambiguous suffix, starting at three. */
export declare function publicKeyLabels(pubkeys: Iterable<string>): ReadonlyMap<string, string>;
